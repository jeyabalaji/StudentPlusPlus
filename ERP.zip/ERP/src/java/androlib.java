/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.*;
import java.io.*;


/**
 *
 * @author Srivatsan
 */
@WebServlet(urlPatterns = {"/androlib"})
public class androlib extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            JSONObject obj = new JSONObject();
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
          
            //System.out.println("welcome");
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","jass");
                Statement stmt = con.createStatement();
                String reg =request.getParameter("regno");
                String q1 = "select * from library where reg_no='"+reg+"'and due_date>(select curdate());";
                
                ResultSet rs1 = stmt.executeQuery(q1);
                JSONArray ja = new JSONArray();
                while(rs1.next())
                {
                    JSONObject jo = new JSONObject();
                    jo.put("name", rs1.getString("book name"));
                    jo.put("author", rs1.getString("author"));
                    jo.put("due", rs1.getString("due_date"));
                    ja.add(jo);
                }                       
                //JSONObject mainObj = new JSONObject();
                obj.put("books", ja);                                                
                
                StringWriter out1 = new StringWriter();
                 obj.writeJSONString(out1);
      
                String jsonText = out1.toString();
                out.print(jsonText);
            }
            
            catch(Exception e){ 
                System.out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
