/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.*;

/**
 *
 * @author Srivatsan
 */
@WebServlet(urlPatterns = {"/androtime_table"})
public class androtime_table extends HttpServlet {

    String rid;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
        try (PrintWriter out = response.getWriter()) {
            //JSONArray arr = new JSONArray();
            //String n=(String)request.getAttribute("name");
            /* TODO output your page here. You may use following sample code. */
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","jass");
                Statement stmt = con.createStatement();
                String rid =request.getParameter("regno");
                 
                String q1 = "select * from time_table where class=(select class from profile where regno='"+rid+"');";
                ResultSet rs1 = stmt.executeQuery(q1);
                int loc;
                JSONObject obj = new JSONObject();
                              
                 JSONArray ja = new JSONArray();
                while(rs1.next())
                {
                    JSONObject jo = new JSONObject();
                    jo.put("day", rs1.getString("day"));
                    jo.put("hour1", rs1.getString("hour1"));
                    jo.put("hour2", rs1.getString("hour2"));
                    jo.put("hour3", rs1.getString("hour3"));
                    jo.put("hour4", rs1.getString("hour4"));
                    jo.put("hour5", rs1.getString("hour5"));
                    jo.put("hour6", rs1.getString("hour6"));
                    jo.put("hour7", rs1.getString("hour7"));
                    jo.put("hour8", rs1.getString("hour8"));
                    ja.add(jo);
                }
                    
                  obj.put("timetable", ja);   
                    
                    
                    
                    /*loc = rs1.getRow();
                    obj.put("day", rs1.getString(2));
                    try{
                        
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","jass");
                    Statement stmt2 = con.createStatement();
                    for (int i=3; i<10;i++)
                    {                        
                        obj.put("hour"+(i-2) , rs1.getString(1));
                        rs2.close();
                        System.out.println("Column "+i);
                    }
                    }
                    catch(Exception e)
                    {
                        System.out.println(e);
                    }
                    //arr.add(obj);
                    /*
                    q1 = "select * from time_table where class=(select class from profile where regno='"+rid+"');";
                    rs1 = stmt.executeQuery(q1); rs1.next();
                    String q3 = "select title from subject where sub_code='"+rs1.getString(4)+"';";
                    ResultSet rs3 = stmt.executeQuery(q3);rs3.next();
                    out.println("<td>" + rs3.getString(1)+ "</td>");
                    System.out.println("Column 4");
                    String q4 = "select title from subject where sub_code='"+rs1.getString(5)+"';";
                    ResultSet rs4 = stmt.executeQuery(q4);rs4.next();
                    out.println("<td>" + rs4.getString(1)+ "</td>");
                    System.out.println("Column 5");
                    /*q2 = "select title from subject where sub_code='"+rs1.getString(6)+"';";
                    rs2 = stmt.executeQuery(q2);rs2.next();
                    out.println("<td>" + rs2.getString(1)+ "</td>");
                    q2 = "select title from subject where sub_code='"+rs1.getString(7)+"';";
                    rs2 = stmt.executeQuery(q2);rs2.next();
                    out.println("<td>" + rs2.getString(1)+ "</td>");
                    q2 = "select title from subject where sub_code='"+rs1.getString(8)+"';";
                    rs2 = stmt.executeQuery(q2);rs2.next();
                    out.println("<td>" + rs2.getString(1)+ "</td>");
                    q2 = "select title from subject where sub_code='"+rs1.getString(9)+"';";
                    rs2 = stmt.executeQuery(q2);rs2.next();
                    out.println("<td>" + rs2.getString(1)+ "</td></tr>");*/
                
                //JSONObject mObj = new JSONObject();
                //mObj.put("time_table", arr);
                StringWriter out1 = new StringWriter();
                 obj.writeJSONString(out1);
      
                String jsonText = out1.toString();
                out.print(jsonText);//out.println("</html>");
            }
            
            catch(Exception e){ 
                System.out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}